package com.example.eima_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
